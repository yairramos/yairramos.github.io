<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Libro</title>
    <style>
        /* Estilos generales */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f9;
        }

        /* Contenedor */
        .container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        /* Título */
        h2 {
            text-align: center;
            color: #333;
        }

        /* Estilo de formulario */
        form label {
            display: block;
            margin: 15px 0 5px;
            font-weight: bold;
        }

        form input[type="text"],
        form input[type="number"],
        form select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        /* Botón de acción */
        .btn {
            text-decoration: none;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            display: inline-block;
            text-align: center;
            margin-top: 15px;
            background-color: #4CAF50;
            display: block;
            width: 100%;
            text-align: center;
        }

        .btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Editar Libro</h2>
        <form action="index.php?page=libros_update" method="POST">
            <input type="hidden" name="id" value="<?php echo $libro['id_libro']; ?>">

            <label>Título:</label>
            <input type="text" name="titulo" value="<?php echo $libro['titulo']; ?>" required>

            <label>Editorial:</label>
            <input type="text" name="editorial" value="<?php echo $libro['editorial']; ?>" required>

            <label>Año Publicación:</label>
            <input type="number" name="anio_publicacion" value="<?php echo $libro['año_publicacion']; ?>" required>

            <label>Carrera (opcional):</label>
            <select name="id_carrera">
                <option value="">Sin Carrera</option>
                <?php foreach ($carreras as $carrera): ?>
                    <option value="<?php echo $carrera['id_carrera']; ?>" 
                        <?php echo ($carrera['id_carrera'] == $libro['id_carrera']) ? 'selected' : ''; ?>>
                        <?php echo $carrera['nombre_carrera']; ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Autor:</label>
            <select name="id_autor" required>
                <option value="">Seleccione un autor</option>
                <?php foreach ($autores as $autor): ?>
                    <option value="<?php echo $autor['id_autor']; ?>" 
                        <?php echo ($autor['id_autor'] == $libro['id_autor']) ? 'selected' : ''; ?>>
                        <?php echo $autor['nombre_autor']; ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Categoría:</label>
            <select name="id_categoria" required>
                <option value="">Seleccione una categoría</option>
                <?php foreach ($categorias as $categoria): ?>
                    <option value="<?php echo $categoria['id_categoria']; ?>" 
                        <?php echo ($categoria['id_categoria'] == $libro['id_categoria']) ? 'selected' : ''; ?>>
                        <?php echo $categoria['nombre_categoria']; ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="btn">Guardar Cambios</button>
        </form>
    </div>
</body>
</html>
