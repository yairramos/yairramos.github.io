<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Libros</title>
    <style>
        /* Estilos generales */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f9;
        }

        /* Título */
        h2 {
            text-align: center;
            color: #333;
        }

        /* Estilos de la tabla */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #333;
            color: white;
            text-transform: uppercase;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        /* Botones */
        .btn {
            text-decoration: none;
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            margin: 5px;
            display: inline-block;
        }

        .btn-add {
            background-color: #4CAF50; /* Verde */
            margin-bottom: 10px;
            display: inline-block;
        }

        .btn-edit {
            background-color: #ffc107; /* Amarillo */
        }

        .btn-delete {
            background-color: #f44336; /* Rojo */
        }

        .btn-add:hover {
            background-color: #45a049;
        }

        .btn-edit:hover {
            background-color: #e0a800;
        }

        .btn-delete:hover {
            background-color: #d32f2f;
        }

        /* Contenedor para centrar */
        .container {
            max-width: 1000px;
            margin: auto;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Lista de Libros</h2>

        <!-- Solo mostrar el botón de agregar si es personal -->
        <?php if ($_SESSION['tipo_usuario'] == 'personal'): ?>
            <a href="index.php?page=libros_create" class="btn btn-add">Agregar Libro</a>
        <?php endif; ?>

        <table>
            <tr>
                <th>Título</th>
                <th>Editorial</th>
                <th>Año Publicación</th>
                <th>Estado</th>
                <th>Carrera</th>
                <th>Autor</th>
                <th>Categoría</th>
                <!-- Mostrar columna de acciones solo para personal -->
                <?php if ($_SESSION['tipo_usuario'] == 'personal'): ?>
                    <th>Acciones</th>
                <?php endif; ?>
            </tr>
            <!-- Comprobar si hay libros en la base de datos -->
            <?php if (!empty($libros)): ?>
                <?php foreach ($libros as $libro): ?>
                    <tr>
                        <td><?php echo $libro['titulo']; ?></td>
                        <td><?php echo $libro['editorial']; ?></td>
                        <td><?php echo $libro['año_publicacion']; ?></td>
                        <td><?php echo $libro['nombre_estado']; ?></td>
                        <td><?php echo $libro['nombre_carrera']; ?></td>
                        <td><?php echo $libro['nombre_autor']; ?></td>
                        <td><?php echo $libro['nombre_categoria']; ?></td>
                        <!-- Mostrar botones de edición y eliminación solo para personal -->
                        <?php if ($_SESSION['tipo_usuario'] == 'personal'): ?>
                            <td>
                                <a href="index.php?page=libros_edit&id=<?php echo $libro['id_libro']; ?>" class="btn btn-edit">Editar</a>
                                <a href="index.php?page=libros_delete&id=<?php echo $libro['id_libro']; ?>" class="btn btn-delete" onclick="return confirm('¿Estás seguro de que deseas eliminar este libro?');">Eliminar</a>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="<?php echo ($_SESSION['tipo_usuario'] == 'personal') ? 8 : 7; ?>">No se encontraron libros.</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
</body>
</html>
