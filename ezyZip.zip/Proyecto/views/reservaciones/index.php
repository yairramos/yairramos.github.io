<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalles de Reservaciones</title>
    <style>
        /* Estilos generales */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f9;
        }

        /* Título */
        h2 {
            text-align: center;
            color: #333;
        }

        /* Estilos de la tabla */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #333;
            color: white;
            text-transform: uppercase;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        /* Botones */
        .btn {
            text-decoration: none;
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            margin: 5px;
            display: inline-block;
        }

        .btn-add {
            background-color: #4CAF50; /* Verde */
            margin-bottom: 10px;
            display: inline-block;
        }

        .btn-edit {
            background-color: #ffc107; /* Amarillo */
        }

        .btn-delete {
            background-color: #f44336; /* Rojo */
        }

        .btn-add:hover {
            background-color: #45a049;
        }

        .btn-edit:hover {
            background-color: #e0a800;
        }

        .btn-delete:hover {
            background-color: #d32f2f;
        }

        /* Contenedor para centrar */
        .container {
            max-width: 1000px;
            margin: auto;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Detalles de Reservaciones</h2>
        <a href="index.php?page=reservaciones_create" class="btn btn-add">Crear Nueva Reservación</a>
        <table>
            <tr>
                <th>Usuario</th>
                <th>Libro</th>
                <th>Fecha de Reservación</th>
                <th>Fecha de Vencimiento</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
            <?php if (!empty($reservaciones)): ?>
                <?php foreach ($reservaciones as $reservacion): ?>
                    <tr>
                        <td><?php echo $reservacion['nombre'] . ' ' . $reservacion['apellido']; ?></td>
                        <td><?php echo $reservacion['titulo']; ?></td>
                        <td><?php echo $reservacion['fecha_reservacion']; ?></td>
                        <td><?php echo $reservacion['fecha_vencimiento']; ?></td>
                        <td><?php echo $reservacion['estado']; ?></td>
                        <td>
                            <a href="index.php?page=reservaciones_edit&id=<?php echo $reservacion['id_reservacion']; ?>" class="btn btn-edit">Editar</a>
                            <a href="index.php?page=reservaciones_delete&id=<?php echo $reservacion['id_reservacion']; ?>" onclick="return confirm('¿Estás seguro de eliminar esta reservación?');" class="btn btn-delete">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No hay reservaciones para este libro.</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
</body>
</html>
