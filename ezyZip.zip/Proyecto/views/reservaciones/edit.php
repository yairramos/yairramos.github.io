<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Reservación</title>
    <style>
        /* Estilos generales */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f9;
        }

        /* Contenedor */
        .container {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        /* Título */
        h2 {
            text-align: center;
            color: #333;
        }

        /* Estilo de formulario */
        form label {
            display: block;
            margin: 15px 0 5px;
            font-weight: bold;
        }

        form input[type="text"],
        form input[type="date"],
        form select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        /* Botón de acción */
        .btn {
            text-decoration: none;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            display: inline-block;
            text-align: center;
            margin-top: 15px;
            background-color: #4CAF50;
            display: block;
            width: 100%;
            text-align: center;
        }

        .btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Editar Reservación</h2>
        <form action="index.php?page=reservaciones_update" method="POST">
            <input type="hidden" name="id" value="<?php echo $reservacion['id_reservacion']; ?>">

            <label>Libro:</label>
            <select name="id_libro" required>
                <?php foreach ($libros as $libro): ?>
                    <option value="<?php echo $libro['id_libro']; ?>" <?php echo ($libro['id_libro'] == $reservacion['id_libro']) ? 'selected' : ''; ?>>
                        <?php echo $libro['titulo']; ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Usuario:</label>
            <select name="id_persona" required>
                <?php foreach ($usuarios as $usuario): ?>
                    <option value="<?php echo $usuario['id_persona']; ?>" <?php echo ($usuario['id_persona'] == $reservacion['id_persona']) ? 'selected' : ''; ?>>
                        <?php echo $usuario['nombre'] . ' ' . $usuario['apellido']; ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Fecha de Reservación:</label>
            <input type="date" name="fecha_reservacion" value="<?php echo $reservacion['fecha_reservacion']; ?>" required>

            <label>Fecha de Vencimiento:</label>
            <input type="date" name="fecha_vencimiento" value="<?php echo $reservacion['fecha_vencimiento']; ?>" required>

            <label>Estado:</label>
            <input type="text" name="estado" value="<?php echo $reservacion['estado']; ?>" required>

            <button type="submit" class="btn">Guardar Cambios</button>
        </form>
    </div>
</body>
</html>
