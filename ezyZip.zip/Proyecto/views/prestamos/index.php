<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Préstamos</title>
    <style>
        /* Estilos generales */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f9;
        }

        /* Título */
        h2 {
            text-align: center;
            color: #333;
        }

        /* Estilos de la tabla */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #333;
            color: white;
            text-transform: uppercase;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        /* Botones */
        .btn {
            text-decoration: none;
            color: white;
            padding: 8px 16px;
            border-radius: 5px;
            margin: 5px;
            display: inline-block;
        }

        .btn-add {
            background-color: #4CAF50; /* Verde */
            margin-bottom: 10px;
            display: inline-block;
        }

        .btn-edit {
            background-color: #ffc107; /* Amarillo */
        }

        .btn-delete {
            background-color: #f44336; /* Rojo */
        }

        .btn-add:hover {
            background-color: #45a049;
        }

        .btn-edit:hover {
            background-color: #e0a800;
        }

        .btn-delete:hover {
            background-color: #d32f2f;
        }

        /* Contenedor para centrar */
        .container {
            max-width: 1000px;
            margin: auto;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Lista de Préstamos</h2>
        <a href="index.php?page=prestamos_create" class="btn btn-add">Registrar Préstamo</a>
        <table>
            <tr>
                <th>Usuario</th>
                <th>Libro</th>
                <th>Fecha de Préstamo</th>
                <th>Fecha de Devolución</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
            <?php foreach ($prestamos as $prestamo): ?>
                <tr>
                    <td><?php echo $prestamo['nombre'] . ' ' . $prestamo['apellido']; ?></td>
                    <td><?php echo $prestamo['titulo']; ?></td>
                    <td><?php echo $prestamo['fecha_prestamo']; ?></td>
                    <td><?php echo $prestamo['fecha_devolucion']; ?></td>
                    <td><?php echo $prestamo['estado']; ?></td>
                    <td>
                        <a href="index.php?page=prestamos_edit&id=<?php echo $prestamo['id_prestamo']; ?>" class="btn btn-edit">Editar</a>
                        <a href="index.php?page=prestamos_delete&id=<?php echo $prestamo['id_prestamo']; ?>" onclick="return confirm('¿Estás seguro de eliminar este préstamo?');" class="btn btn-delete">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>
